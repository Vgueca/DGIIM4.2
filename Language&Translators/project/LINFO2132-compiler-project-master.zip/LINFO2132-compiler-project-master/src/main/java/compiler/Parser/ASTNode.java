package compiler.Parser;

public class ASTNode {
    @Override
    public String toString() {
        return "ASTNode{}";
    }
}
