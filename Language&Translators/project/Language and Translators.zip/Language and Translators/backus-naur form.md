# Progress in the Backus-Naur form of the custom language

```
🔴 Not started.
🟠 Started.
🟡 Nearly finished.
🟢 Done.
```

```go
🟢 <program> ::= <const>* <record-declaration>* <val-var>* <procedure>*

🟢 <const> ::= "const" <IDENTIFIER> <base-type> "=" <expression> ";"
🟢 <value> ::= "val" <IDENTIFIER> <base-type> "=" <expression> ";"
🟢 <variable> ::= "var" <IDENTIFIER> <type> "=" <expression> ";"
🟢 <val-var> ::= <variable> | <value>
🟢 <record-declaration> ::= "record" <IDENTIFIER> "{" <field-declaration>* "}"
🟢 <field-declaration> ::= <IDENTIFIER> <type> ";"

🟢 <type> ::= <base-type> | <IDENTIFIER> | <array-type>
🟢 <base-type> ::= "int" | "real" | "bool" | "string"
🟢 <array-type> ::= <base-type> "[]"

🟢 <expression> ::= <bool-term> ( ( "or" | "and" ) <expression> )?
🟢 <bool-term> ::= <bool-factor> ( ( "<" | "<=" | ">" | ">=" | "==" | "<>" ) <bool-term> )?
🟢 <bool-factor> ::= <arith-term> ( ( "+" | "-" ) <bool-factor> )?
🟢 <arith-term> ::= <arith-factor> ( ( "*" | "/" | "%" ) <arith-term> )?
🟢 <arith-factor> ::= ( "+" | "-" )? <primary>
🟢 <primary> ::= <literal> | <IDENTIFIER> | <function-call> | "(" <expression> ")" | <array-access> | <record-access>

🟢 <literal> ::= <INT> | <REAL> | <BOOL> | <STRING>
🟢 <function-call> ::= <IDENTIFIER> "(" (<expression> ("," <expression>)*)? ")"
🟢 <array-access> ::= <IDENTIFIER> "[" <expression> "]"
🟢 <record-access> ::= (<IDENTIFIER> | <array-access>) "." <IDENTIFIER>

🟢 <procedure> ::= "proc" <IDENTIFIER> "(" (<parameter> ("," <parameter>)*)? ")" <return-type> <block>
🟢 <parameter> ::= <IDENTIFIER> <type>
🟢 <return-type> ::= <type> | "void"
🟢 <block> ::= "{" <statement>* "}"
🟢 <statement> ::= <val-var> | <if> | <while> | <for> | <assignment> | <function-call> | <return> | <delete>

🟢 <if> ::= "if" <expression> <block> ("else" <block>)?
🟢 <while> ::= "while" <expression> <block>
🟢 <for> ::= "for" <IDENTIFIER> "=" <INT> "to" <INT> ("by" <INT>)? <block>
🟢 <assignment> ::= (<IDENTIFIER> | <array-access> | <record-access>) "=" <expression> ";"
🟢 <return> ::= "return" <expression> ";"
🟢 <delete> ::= "delete" <IDENTIFIER> ";"
```
