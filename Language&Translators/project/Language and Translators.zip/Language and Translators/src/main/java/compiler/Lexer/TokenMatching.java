package compiler.Lexer;

public interface TokenMatching {
    static boolean isTokenMatched(String code) {
        return false;
    }
}
