package compiler.Parser;

import compiler.Parser.Visitors.Visitable;

/**
 * Represents a node of an AST.
 */
public abstract class ASTNode implements Visitable {
    public abstract String toString();

    public abstract boolean equals(Object obj);

    public abstract int hashCode();
}
