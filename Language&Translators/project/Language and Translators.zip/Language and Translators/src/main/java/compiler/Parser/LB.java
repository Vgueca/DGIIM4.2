package compiler.Parser;

import compiler.Lexer.Lexer;
import compiler.Lexer.Symbol;
import compiler.Lexer.Token;

import java.text.ParseException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Lexer Buffer with symbol preview.
 */
public class LB {
    Lexer lexer;
    LinkedList<Symbol> symbols;
    List<Symbol> progress;

    public LB(Lexer lexer) {
        this.lexer = lexer;
        symbols = new LinkedList<>();
        progress = new LinkedList<>();
    }

    /**
     * Gets the next symbol and add it to the progress.
     * 
     * @return the next Symbol.
     */
    public Symbol get() {
        Symbol next = silentGet();
        progress.add(next);
        return next;
    }

    /**
     * Gets the next symbol without adding it to the progress (used for checking values).
     *
     * @return
     */
    private Symbol silentGet() {
        return symbols.isEmpty() ? lexer.getNextSymbol() : symbols.remove();
    }

    /**
     * Get the next symbol and check if the token type is right.
     * 
     * @param token the token type of the next symbol.
     * @return the next symbol.
     * @throws ParseException if the types don't match.
     */
    public Symbol match(Token token) throws ParseException {
        return matchAny(new Token[] { token });
    }

    /**
     * Get the next symbol and check if the token type matches any one of tokens.
     * 
     * @param tokens an array of token types that the next symbol could be.
     * @return the next symbol.
     * @throws ParseException if the type don't match with any of the array.
     */
    public Symbol matchAny(Token[] tokens) throws ParseException {
        Symbol symbol = get();

        if (!Arrays.asList(tokens).contains(symbol.getToken()))
            throw new ParseException(
                    "Expected a " + Arrays.toString(tokens) + " token but got a " + symbol.getToken(), 0);

        return symbol;
    }

    /**
     * Consume the next symbol while checking its token type.
     * 
     * @param token the token type of the next symbol.
     * @throws ParseException if the types don't match.
     */
    public void consume(Token token) throws ParseException {
        match(token);
    }

    /**
     * Get the next symbol without consuming it.
     * 
     * @return the next symbol.
     */
    public Symbol peek() {
        if (symbols.isEmpty())
            symbols.add(lexer.getNextSymbol());
        return symbols.peek();
    }

    /**
     * Get the symbol after the next symbol without consuming it.
     *
     * @return the 2nd next symbol.
     */
    public Symbol peek2() {
        while (symbols.size() < 2)
            symbols.add(lexer.getNextSymbol());

        Symbol first = silentGet();
        Symbol second = symbols.peek();
        symbols.addFirst(first);
        return second;
    }

    /**
     * Produces a string with the code of the tokens that have already been read.
     *
     * @return a String of already parsed code.
     */
    public String getProgress() {
        StringBuilder ret = new StringBuilder();
        for (int i = 0; i < progress.size(); i++) {
            if (i > 0)
                ret.append(" ");
            ret.append(progress.get(i).getContent());
        }
        return ret.toString();
    }
}
