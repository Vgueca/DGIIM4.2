package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public abstract class ArithFactorNode extends ASTNode {
    public ASTNode prim;

    public ArithFactorNode(ASTNode prim) {
        this.prim = prim;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ArithFactorNode that = (ArithFactorNode) o;
        return Objects.equals(prim, that.prim);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
        visitor.visit(this, st);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prim);
    }

    public static class Positive extends ArithFactorNode {
        public Positive(ASTNode prim) {
            super(prim);
        }

        @Override
        public String toString() {
            return "+" + prim.toString();
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            prim.accept(visitor, depth + 1);
        }
    }

    public static class Negative extends ArithFactorNode {
        public Negative(ASTNode prim) {
            super(prim);
        }

        @Override
        public String toString() {
            return "-" + prim.toString();
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            prim.accept(visitor, depth + 1);
        }
    }

    @Override
    public String toString() {
        return "[+|-]" + prim.toString();
    }
}
