package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class ArithTermNode extends ASTNode {
    public ASTNode left;
    public ASTNode right;

    public ArithTermNode(ASTNode left, ASTNode right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        left.accept(visitor, depth + 1);
        right.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        left.accept(visitor, st);
        right.accept(visitor, st);
    }

    public static class Multiplication extends ArithTermNode {
        public Multiplication(ASTNode left, ASTNode right) {
            super(left, right);
        }

        @Override
        public String toString() {
            return "(" + left + " * " + right + ")";
        }
    }

    public static class Division extends ArithTermNode {
        public Division(ASTNode left, ASTNode right) {
            super(left, right);
        }

        @Override
        public String toString() {
            return "(" + left + " / " + right + ")";
        }
    }

    public static class Modulo extends ArithTermNode {
        public Modulo(ASTNode left, ASTNode right) {
            super(left, right);
        }

        @Override
        public String toString() {
            return "(" + left + " % " + right + ")";
        }
    }

    @Override
    public String toString() {
        return "(" + left + "[*|/|%]" + right + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ArithTermNode that = (ArithTermNode) o;
        return Objects.equals(left, that.left) && Objects.equals(right, that.right);
    }

    @Override
    public int hashCode() {
        return Objects.hash(left, right);
    }
}
