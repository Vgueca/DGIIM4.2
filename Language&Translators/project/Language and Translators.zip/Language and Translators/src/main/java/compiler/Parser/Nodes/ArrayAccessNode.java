package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class ArrayAccessNode extends ASTNode {
    public IdentifierNode identifier;
    public ASTNode index; // expression

    public ArrayAccessNode(IdentifierNode identifier, ASTNode index) {
        this.identifier = identifier;
        this.index = index;
    }

    @Override
    public String toString() {
        return "(AA " + identifier + " [" + index + "])";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ArrayAccessNode that = (ArrayAccessNode) o;
        return Objects.equals(identifier, that.identifier) && Objects.equals(index, that.index);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier, index);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        identifier.accept(visitor, depth + 1);
        index.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        identifier.accept(visitor, st);
        index.accept(visitor, st);
    }
}
