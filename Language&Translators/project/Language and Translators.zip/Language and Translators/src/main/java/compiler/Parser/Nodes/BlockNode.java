package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Objects;

public class BlockNode extends ASTNode {
    ArrayList<ASTNode> statements;

    public BlockNode(ArrayList<ASTNode> statements) {
        this.statements = statements;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder("{");
        for (ASTNode s : statements)
            ret.append("\n").append(s);
        return ret + "\n}";
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        depth++;
        for (ASTNode s : statements) {
            s.accept(visitor, depth);
        }
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);

        SymbolTable newst = new SymbolTable(st);
        for (ASTNode s : statements) {
            s.accept(visitor, newst);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        BlockNode blockNode = (BlockNode) o;
        return Objects.equals(statements, blockNode.statements);
    }

    @Override
    public int hashCode() {
        return Objects.hash(statements);
    }
}
