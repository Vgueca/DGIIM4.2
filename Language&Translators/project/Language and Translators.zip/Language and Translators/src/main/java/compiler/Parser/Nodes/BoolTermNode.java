package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public abstract class BoolTermNode extends ASTNode {
    public ASTNode left;
    public ASTNode right;

    public BoolTermNode(ASTNode left, ASTNode right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        left.accept(visitor, depth + 1);
        right.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        left.accept(visitor, st);
        right.accept(visitor, st);
    }

    public static class Lower extends BoolTermNode {
        public Lower(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " < " + right + ")";
        }
    }

    public static class LEQ extends BoolTermNode {
        public LEQ(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " <= " + right + ")";
        }
    }

    public static class Greater extends BoolTermNode {
        public Greater(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " > " + right + ")";
        }
    }

    public static class GEQ extends BoolTermNode {
        public GEQ(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " >= " + right + ")";
        }
    }

    public static class Equal extends BoolTermNode {
        public Equal(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " == " + right + ")";
        }
    }

    public static class Different extends BoolTermNode {
        public Different(ASTNode left, ASTNode astNode) {
            super(left, astNode);
        }

        @Override
        public String toString() {
            return "(" + left + " <> " + right + ")";
        }
    }

    @Override
    public String toString() {
        return "(" + left + " [<|<=|>|>=|==|<>] " + right + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        BoolTermNode that = (BoolTermNode) o;
        return Objects.equals(left, that.left) && Objects.equals(right, that.right);
    }

    @Override
    public int hashCode() {
        return Objects.hash(left, right);
    }
}
