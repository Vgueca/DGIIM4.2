package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

/**
 * CVVNode is a Constant-Value-Variable node that represents any of a const, val, or var.
 */
public abstract class CVVNode extends ASTNode {
    public IdentifierNode identifier;
    public TypeNode type;
    public ASTNode expression;

    public CVVNode(IdentifierNode identifier, TypeNode type, ASTNode expression) {
        this.identifier = identifier;
        this.type = type;
        this.expression = expression;
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        identifier.accept(visitor, depth + 1);
        type.accept(visitor, depth + 1);
        expression.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        identifier.accept(visitor, st);
        type.accept(visitor, st);
        expression.accept(visitor, st);
    }

    public static class Const extends CVVNode {
        public Const(IdentifierNode identifier, TypeNode.Base baseType, ASTNode expression) {
            super(identifier, baseType, expression);
        }

        @Override
        public String toString() {
            return "(const " + identifier + " " + type + " " + expression + ")";
        }
    }

    public static class Val extends CVVNode {
        public Val(IdentifierNode identifier, TypeNode.Base baseType, ASTNode expression) {
            super(identifier, baseType, expression);
        }

        @Override
        public String toString() {
            return "(val " + identifier + " " + type + " " + expression + ")";
        }
    }

    public static class Var extends CVVNode {
        public Var(IdentifierNode identifier, TypeNode type, ASTNode expression) {
            super(identifier, type, expression);
        }

        @Override
        public String toString() {
            return "(var " + identifier + " " + type + " " + expression + ")";
        }
    }

    @Override
    public String toString() {
        return "(CVV " + identifier + " " + type + " " + expression + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CVVNode cvvNode = (CVVNode) o;
        return Objects.equals(identifier, cvvNode.identifier) && Objects.equals(type, cvvNode.type)
                && Objects.equals(expression, cvvNode.expression);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier, type, expression);
    }
}
