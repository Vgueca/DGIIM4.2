package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class DeleteNode extends ASTNode {
    public IdentifierNode deleted;

    public DeleteNode(IdentifierNode returned) {
        this.deleted = returned;
    }

    @Override
    public String toString() {
        return "(delete " + deleted + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        DeleteNode that = (DeleteNode) o;
        return Objects.equals(deleted, that.deleted);
    }

    @Override
    public int hashCode() {
        return Objects.hash(deleted);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        deleted.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
        visitor.visit(this, st);
        deleted.accept(visitor, st);
    }
}
