package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public abstract class ExpressionNode extends ASTNode {
    public ASTNode left;
    public ASTNode right;

    public ExpressionNode(ASTNode left, ASTNode right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        left.accept(visitor, depth + 1);
        right.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        left.accept(visitor, st);
        right.accept(visitor, st);
    }

    public static class Or extends ExpressionNode {
        public Or(ASTNode left, ASTNode right) {
            super(left, right);
        }

        @Override
        public String toString() {
            return "(" + left + " or " + right + ")";
        }
    }

    public static class And extends ExpressionNode {
        public And(ASTNode left, ASTNode right) {
            super(left, right);
        }

        @Override
        public String toString() {
            return "(" + left + " and " + right + ")";
        }
    }

    @Override
    public String toString() {
        return "(" + left + " [or|and] " + right + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ExpressionNode that = (ExpressionNode) o;
        return Objects.equals(left, that.left) && Objects.equals(right, that.right);
    }

    @Override
    public int hashCode() {
        return Objects.hash(left, right);
    }
}
