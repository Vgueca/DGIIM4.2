package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class ForNode extends ASTNode {
    IdentifierNode i;
    LiteralNode.Int from;
    LiteralNode.Int to;
    BlockNode block;

    public ForNode(IdentifierNode i, LiteralNode.Int from, LiteralNode.Int to, BlockNode block) {
        this.i = i;
        this.from = from;
        this.to = to;
        this.block = block;
    }

    @Override
    public String toString() {
        return "(for " + i + "=" + from + " to " + to + block + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ForNode forNode = (ForNode) o;
        return Objects.equals(i, forNode.i) && Objects.equals(from, forNode.from) && Objects.equals(to, forNode.to)
                && Objects.equals(block, forNode.block);
    }

    @Override
    public int hashCode() {
        return Objects.hash(i, from, to, block);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        i.accept(visitor, depth + 1);
        from.accept(visitor, depth + 1);
        to.accept(visitor, depth + 1);
        block.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);

        SymbolTable newst = new SymbolTable(st);
        i.accept(visitor, newst);
        from.accept(visitor, newst);
        to.accept(visitor, newst);
        block.accept(visitor, newst);
    }

    public static class By extends ForNode {
        LiteralNode.Int by;

        public By(IdentifierNode i, LiteralNode.Int from, LiteralNode.Int to, LiteralNode.Int by, BlockNode block) {
            super(i, from, to, block);
            this.by = by;
        }

        @Override
        public String toString() {
            return "(for " + i + "=" + from + " to " + to + " by " + by + block + ")";
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            i.accept(visitor, depth + 1);
            from.accept(visitor, depth + 1);
            to.accept(visitor, depth + 1);
            by.accept(visitor, depth + 1);
            block.accept(visitor, depth + 1);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
            visitor.visit(this, st);
            i.accept(visitor, st);
            from.accept(visitor, st);
            to.accept(visitor, st);
            by.accept(visitor, st);

            SymbolTable newst = new SymbolTable(st);
            block.accept(visitor, newst);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            if (!super.equals(o))
                return false;
            By by1 = (By) o;
            return Objects.equals(by, by1.by);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), by);
        }
    }
}
