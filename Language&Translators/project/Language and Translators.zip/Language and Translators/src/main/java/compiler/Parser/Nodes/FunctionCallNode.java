package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Objects;

public class FunctionCallNode extends ASTNode {
    public IdentifierNode identifier;

    public ArrayList<ASTNode> args; // expressions

    public FunctionCallNode(IdentifierNode identifier, ArrayList<ASTNode> args) {
        this.identifier = identifier;
        this.args = args;
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        depth++;
        identifier.accept(visitor, depth);
        for (ASTNode a : args) {
            a.accept(visitor, depth);
        }
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        identifier.accept(visitor, st);

        SymbolTable newst = new SymbolTable(st);
        for (ASTNode a : args) {
            a.accept(visitor, newst);
        }
    }

    @Override
    public String toString() {
        return "(call " + identifier + " (" + args + "))";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        FunctionCallNode that = (FunctionCallNode) o;
        return Objects.equals(identifier, that.identifier) && Objects.equals(args, that.args);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier, args);
    }
}
