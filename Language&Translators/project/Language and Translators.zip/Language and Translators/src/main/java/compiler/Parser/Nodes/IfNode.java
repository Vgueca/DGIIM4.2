package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class IfNode extends ASTNode {
    public ASTNode condition;
    public BlockNode block;

    public IfNode(ASTNode condition, BlockNode ifBlock) {
        this.condition = condition;
        this.block = ifBlock;
    }

    @Override
    public String toString() {
        return "(if " + condition + block + ")";
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        condition.accept(visitor, depth + 1);
        block.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        condition.accept(visitor, st);


        SymbolTable newst = new SymbolTable(st);
        block.accept(visitor, newst);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        IfNode ifNode = (IfNode) o;
        return Objects.equals(condition, ifNode.condition) && Objects.equals(block, ifNode.block);
    }

    @Override
    public int hashCode() {
        return Objects.hash(condition, block);
    }

    public static class Else extends IfNode {
        BlockNode elseBlock;

        public Else(ASTNode condition, BlockNode ifBlock, BlockNode elseBlock) {
            super(condition, ifBlock);
            this.elseBlock = elseBlock;
        }

        @Override
        public String toString() {
            return "(if " + condition + block + " else " + elseBlock + ")";
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            condition.accept(visitor, depth + 1);
            block.accept(visitor, depth + 1);
            elseBlock.accept(visitor, depth + 1);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
            visitor.visit(this, st);
            condition.accept(visitor, st);

            SymbolTable newst = new SymbolTable(st);
            block.accept(visitor, newst);
            elseBlock.accept(visitor, newst);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            if (!super.equals(o))
                return false;
            Else anElse = (Else) o;
            return Objects.equals(elseBlock, anElse.elseBlock);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), elseBlock);
        }
    }
}
