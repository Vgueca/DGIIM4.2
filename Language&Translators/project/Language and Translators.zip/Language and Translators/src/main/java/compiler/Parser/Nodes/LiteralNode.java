package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public abstract class LiteralNode extends ASTNode {
    public static class Int extends LiteralNode {
        int content;

        public Int(java.lang.String content) {
            this.content = Integer.parseInt(content);
        }

        @Override
        public java.lang.String toString() {
            return java.lang.String.valueOf(content) + "_I";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Int anInt = (Int) o;
            return content == anInt.content;
        }

        @Override
        public int hashCode() {
            return Objects.hash(content);
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            System.out.println("\t".repeat(depth + 1) + content);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }
    }

    public static class Real extends LiteralNode {
        double content;

        public Real(java.lang.String content) {
            this.content = Double.parseDouble(content);
        }

        @Override
        public java.lang.String toString() {
            return java.lang.String.valueOf(content) + "_R";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Real real = (Real) o;
            return Double.compare(real.content, content) == 0;
        }

        @Override
        public int hashCode() {
            return Objects.hash(content);
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            System.out.println("\t".repeat(depth + 1) + content);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }
    }

    public static class String extends LiteralNode {
        java.lang.String content;

        public String(java.lang.String content) {
            this.content = content;
        }

        @Override
        public java.lang.String toString() {
            return content + "_S";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            String string = (String) o;
            return Objects.equals(content, string.content);
        }

        @Override
        public int hashCode() {
            return Objects.hash(content);
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            System.out.println("\t".repeat(depth + 1) + content);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }
    }

    public static class Bool extends LiteralNode {
        boolean content;

        public Bool(java.lang.String bool) {
            this.content = Boolean.parseBoolean(bool);
        }

        @Override
        public java.lang.String toString() {
            return java.lang.String.valueOf(content) + "_B";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Bool bool = (Bool) o;
            return content == bool.content;
        }

        @Override
        public int hashCode() {
            return Objects.hash(content);
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            System.out.println("\t".repeat(depth + 1) + content);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }
    }

    @Override
    public java.lang.String toString() {
        return "{LiteralNode}";
    }

    @Override
    public boolean equals(Object obj) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
