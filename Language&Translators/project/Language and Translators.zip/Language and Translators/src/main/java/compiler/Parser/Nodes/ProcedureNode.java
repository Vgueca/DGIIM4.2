package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Objects;

public class ProcedureNode extends ASTNode {
    public IdentifierNode identifier;
    public ArrayList<ParameterNode> params;
    public TypeNode returnType;
    public BlockNode block;

    public ProcedureNode(IdentifierNode identifier, ArrayList<ParameterNode> params, TypeNode returnType, BlockNode block) {
        this.identifier = identifier;
        this.params = params == null ? new ArrayList<>() : params;
        this.returnType = returnType;
        this.block = block;
    }

    @Override
    public String toString() {
        return "(proc " + identifier + " " + params + " " + returnType + " " + block + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ProcedureNode that = (ProcedureNode) o;
        return Objects.equals(identifier, that.identifier) && Objects.equals(params, that.params)
                && Objects.equals(returnType, that.returnType) && Objects.equals(block, that.block);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier, params, returnType, block);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        depth++;
        identifier.accept(visitor, depth);
        for (ASTNode p : params) {
            p.accept(visitor, depth);
        }
        returnType.accept(visitor, depth);
        block.accept(visitor, depth);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        identifier.accept(visitor, st);

        SymbolTable newst = new SymbolTable(st);
        for (ASTNode p : params) {
            p.accept(visitor, newst);
        }
        returnType.accept(visitor, st);
        block.accept(visitor, newst);
    }
}
