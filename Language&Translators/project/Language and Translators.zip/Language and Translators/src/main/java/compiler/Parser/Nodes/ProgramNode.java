package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Objects;

public class ProgramNode extends ASTNode {
    ArrayList<ASTNode> constants;
    ArrayList<ASTNode> records;
    ArrayList<CVVNode> valVar;
    ArrayList<ProcedureNode> procedures;

    public ProgramNode(ArrayList<ASTNode> constants, ArrayList<ASTNode> records, ArrayList<CVVNode> valVar,
            ArrayList<ProcedureNode> procedures) {
        this.constants = constants == null ? new ArrayList<>() : constants;
        this.records = records == null ? new ArrayList<>() : records;
        this.valVar = valVar == null ? new ArrayList<>() : valVar;
        this.procedures = procedures == null ? new ArrayList<>() : procedures;
    }

    public ArrayList<ASTNode> getConstants() {
        return constants;
    }

    public ArrayList<ASTNode> getRecords() {
        return records;
    }

    public ArrayList<CVVNode> getValVar() {
        return valVar;
    }

    public ArrayList<ProcedureNode> getProcedures() {
        return procedures;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder("// constants");
        for (ASTNode c : constants)
            ret.append("\n").append(c);
        ret.append("\n// records");
        for (ASTNode r : records)
            ret.append("\n").append(r);
        ret.append("\n// val/var");
        for (CVVNode v : valVar)
            ret.append("\n").append(v);
        ret.append("\n// procedures");
        for (ProcedureNode p : procedures)
            ret.append("\n").append(p);
        return ret.toString();
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        depth++;
        for (ASTNode c : constants)
            c.accept(visitor, depth);
        for (ASTNode r : records)
            r.accept(visitor, depth);
        for (CVVNode v : valVar)
            v.accept(visitor, depth);
        for (ProcedureNode p : procedures)
            p.accept(visitor, depth);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        for (ASTNode c : constants)
            c.accept(visitor, st);
        for (ASTNode r : records)
            r.accept(visitor, st);
        for (CVVNode v : valVar)
            v.accept(visitor, st);
        for (ProcedureNode p : procedures)
            p.accept(visitor,st);


    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ProgramNode that = (ProgramNode) o;
        return Objects.equals(constants, that.constants) && Objects.equals(records, that.records)
                && Objects.equals(valVar, that.valVar) && Objects.equals(procedures, that.procedures);
    }

    @Override
    public int hashCode() {
        return Objects.hash(constants, records, valVar, procedures);
    }
}
