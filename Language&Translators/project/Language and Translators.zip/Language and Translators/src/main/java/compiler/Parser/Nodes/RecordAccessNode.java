package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class RecordAccessNode extends ASTNode {
    public ASTNode record; // identifier or array access
    public IdentifierNode fieldIdentifier;

    public RecordAccessNode(ASTNode record, IdentifierNode fieldIdentifier) {
        this.record = record;
        this.fieldIdentifier = fieldIdentifier;
    }

    @Override
    public String toString() {
        return "(RA " + record + "." + fieldIdentifier + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        RecordAccessNode that = (RecordAccessNode) o;
        return Objects.equals(record, that.record)
                && Objects.equals(fieldIdentifier, that.fieldIdentifier);
    }

    @Override
    public int hashCode() {
        return Objects.hash(record, fieldIdentifier);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        record.accept(visitor, depth + 1);
        fieldIdentifier.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        record.accept(visitor, st);
        fieldIdentifier.accept(visitor, st);
    }
}
