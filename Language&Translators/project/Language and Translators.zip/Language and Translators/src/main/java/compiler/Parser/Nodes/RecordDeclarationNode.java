package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Objects;

public class RecordDeclarationNode extends ASTNode {
    public IdentifierNode identifier;
    public ArrayList<FieldDeclarationNode> fields;

    public RecordDeclarationNode(IdentifierNode identifier, ArrayList<FieldDeclarationNode> fields) {
        this.identifier = identifier;
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "(RD " + identifier + " " + fields + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        RecordDeclarationNode that = (RecordDeclarationNode) o;
        return Objects.equals(identifier, that.identifier) && Objects.equals(fields, that.fields);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier, fields);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        depth++;
        identifier.accept(visitor, depth);
        for (FieldDeclarationNode f : fields)
            f.accept(visitor, depth);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        identifier.accept(visitor, st);
        for (FieldDeclarationNode f : fields)
            f.accept(visitor, st);
    }
}
