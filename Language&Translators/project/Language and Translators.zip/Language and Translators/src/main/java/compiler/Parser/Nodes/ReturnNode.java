package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class ReturnNode extends ASTNode {
    public ASTNode returned;

    public ReturnNode(ASTNode returned) {
        this.returned = returned;
    }

    @Override
    public String toString() {
        return "(return " + returned + ")";
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        returned.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        returned.accept(visitor, st);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ReturnNode that = (ReturnNode) o;
        return Objects.equals(returned, that.returned);
    }

    @Override
    public int hashCode() {
        return Objects.hash(returned);
    }
}
