package compiler.Parser.Nodes;

import compiler.Lexer.Token;
import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public abstract class TypeNode extends ASTNode {
    public static class Base extends TypeNode {
        public Token token;

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            System.out.println("\t".repeat(depth + 1) + token);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }

        public Base(Token token) throws ParseException {
            switch (token) {
                case INTTYPE, REALTYPE, STRINGTYPE, BOOLTYPE -> this.token = token;
                default ->
                    throw new ParseException("Basic TypeNode created but not with int, real, string or bool.", 0);
            }
        }

        @Override
        public String toString() {
            return token.toString() + "_base";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Base base = (Base) o;
            return token == base.token;
        }

        @Override
        public int hashCode() {
            return Objects.hash(token);
        }
    }

    public static class Identifier extends TypeNode {
        public IdentifierNode identifier;

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            depth++;
            identifier.accept(visitor, depth);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }

        public Identifier(IdentifierNode identifier) {
            this.identifier = identifier;
        }

        @Override
        public String toString() {
            return identifier.toString() + "_id";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Identifier that = (Identifier) o;
            return Objects.equals(identifier, that.identifier);
        }

        @Override
        public int hashCode() {
            return Objects.hash(identifier);
        }
    }

    public static class Array extends TypeNode {
        public TypeNode.Base baseType;

        public Array(TypeNode.Base baseType) {
            this.baseType = baseType;
        }

        @Override
        public String toString() {
            return baseType + "[]_ar";
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
            depth++;
            baseType.accept(visitor, depth);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Array array = (Array) o;
            return Objects.equals(baseType, array.baseType);
        }

        @Override
        public int hashCode() {
            return Objects.hash(baseType);
        }
    }

    public static class Void extends TypeNode {

        public Void() {
        }

        @Override
        public void accept(PrintVisitor visitor, int depth) {
            visitor.visit(this, depth);
        }

        @Override
        public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException {
            visitor.visit(this, st);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            return o != null && getClass() == o.getClass();
        }

        @Override
        public int hashCode() {
            return super.hashCode();
        }
    }

    @Override
    public String toString() {
        return "{TypeNode}";
    }

    @Override
    public boolean equals(Object obj) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
