package compiler.Parser.Nodes;

import compiler.Parser.ASTNode;
import compiler.Parser.Visitors.PrintVisitor;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.Objects;

public class WhileNode extends ASTNode {
    ASTNode condition;
    BlockNode block;

    public WhileNode(ASTNode condition, BlockNode block) {
        this.condition = condition;
        this.block = block;
    }

    @Override
    public String toString() {
        return "(while " + condition + " " + block + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        WhileNode whileNode = (WhileNode) o;
        return Objects.equals(condition, whileNode.condition) && Objects.equals(block, whileNode.block);
    }

    @Override
    public int hashCode() {
        return Objects.hash(condition, block);
    }

    @Override
    public void accept(PrintVisitor visitor, int depth) {
        visitor.visit(this, depth);
        condition.accept(visitor, depth + 1);
        block.accept(visitor, depth + 1);
    }

    @Override
    public void accept(SemanticVisitor visitor, SymbolTable st) throws ParseException, SemanticException {
        visitor.visit(this, st);
        condition.accept(visitor, st);

        SymbolTable newst = new SymbolTable(st);
        block.accept(visitor, newst);
    }
}
