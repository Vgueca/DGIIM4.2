package compiler.Parser;

import compiler.Lexer.Lexer;
import compiler.Lexer.Token;
import compiler.Parser.Nodes.*;
import compiler.Parser.Visitors.PrintVisitor;

import java.text.ParseException;
import java.util.ArrayList;

public class Parser {
    private final LB lb;

    public Parser(Lexer lexer) {
        this.lb = new LB(lexer);
    }

    public ProgramNode getAST() throws ParseException {
        return parseProgram();
    }

    public static void printAST(ProgramNode node) {
        PrintVisitor visitor = new PrintVisitor();
        System.out.print("------   AST   ------\n");
        node.accept(visitor, 0);
    }

    private ProgramNode parseProgram() throws ParseException {
        ArrayList<ASTNode> constants = new ArrayList<>();
        while (lb.peek() != null && lb.peek().getToken() == Token.CONST)
            constants.add(parseConstDeclaration());

        ArrayList<ASTNode> records = new ArrayList<>();
        while (lb.peek() != null && lb.peek().getToken() == Token.RECORD)
            records.add(parseRecordDeclaration());

        ArrayList<CVVNode> valVar = new ArrayList<>();
        while (lb.peek() != null && (lb.peek().getToken() == Token.VAL || lb.peek().getToken() == Token.VAR))
            valVar.add(parseValVarDeclaration());

        ArrayList<ProcedureNode> procedures = new ArrayList<>();
        while (lb.peek() != null && lb.peek().getToken() == Token.PROC)
            procedures.add(parseProcedure());

        return new ProgramNode(constants, records, valVar, procedures);
    }

    private ASTNode parseConstDeclaration() throws ParseException {
        lb.consume(Token.CONST);
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        TypeNode.Base baseType = parseBaseType();
        lb.consume(Token.ASSIGNMENT);
        ASTNode expression = parseExpression();
        lb.consume(Token.SEMICOLON);
        return new CVVNode.Const(identifier, baseType, expression);
    }

    private CVVNode parseValVarDeclaration() throws ParseException {
        Token token = lb.peek().getToken();
        if (token == Token.VAL)
            return parseValue();
        else if (token == Token.VAR)
            return parseVariable();

        throw new ParseException("Unexpected val/var initialization.", 0);
    }

    private CVVNode.Val parseValue() throws ParseException {
        lb.consume(Token.VAL);
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        TypeNode.Base baseType = parseBaseType();
        lb.consume(Token.ASSIGNMENT);
        ASTNode expression = parseExpression();
        lb.consume(Token.SEMICOLON);
        return new CVVNode.Val(identifier, baseType, expression);
    }

    private CVVNode.Var parseVariable() throws ParseException {
        lb.consume(Token.VAR);
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        TypeNode type = parseType();
        lb.consume(Token.ASSIGNMENT);
        ASTNode expression = parseExpression();
        lb.consume(Token.SEMICOLON);
        return new CVVNode.Var(identifier, type, expression);
    }

    private ASTNode parseRecordDeclaration() throws ParseException {
        lb.consume(Token.RECORD);
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        lb.consume(Token.OPENCURLYBRACKETS);

        ArrayList<FieldDeclarationNode> fields = new ArrayList<>();
        while (lb.peek().getToken() != Token.CLOSECURLYBRACKETS) {
            fields.add(parseFieldDeclaration());
        }

        lb.consume(Token.CLOSECURLYBRACKETS);
        return new RecordDeclarationNode(identifier, fields);
    }

    private FieldDeclarationNode parseFieldDeclaration() throws ParseException {
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        TypeNode type = parseType();
        lb.consume(Token.SEMICOLON);
        return new FieldDeclarationNode(identifier, type);
    }

    private TypeNode parseType() throws ParseException { // TODO type tests still ok after <base-type>[] arrays?
        Token token = lb.peek().getToken();

        switch (token) {
            case INTTYPE, REALTYPE, STRINGTYPE, BOOLTYPE -> {
                TypeNode.Base baseType = parseBaseType();
                if (lb.peek().getToken() == Token.OPENBRACKETS) {
                    lb.consume(Token.OPENBRACKETS);
                    lb.consume(Token.CLOSEBRACKETS);
                    return new TypeNode.Array(baseType);
                } else
                    return baseType;
            }
            case IDENTIFIER -> {
                return new TypeNode.Identifier(new IdentifierNode(lb.match(Token.IDENTIFIER).getContent()));
            }
        }
        throw new ParseException("Unexpected type (next: " + lb.peek() + ").", 0);
    }

    private TypeNode.Base parseBaseType() throws ParseException {
        Token token = lb.get().getToken();

        if (token == Token.INTTYPE || token == Token.REALTYPE || token == Token.STRINGTYPE || token == Token.BOOLTYPE)
            return new TypeNode.Base(token);

        throw new ParseException("Expected base type (int | real | string | bool) but got " + token + ".", 0);
    }

    /**
     * Builds a tree of bool-term nodes in Or, or And nodes.
     *     OR
     *   /   \
     * bt     AND
     *       /   \
     *     bt     bt
     * @return <ExpressionNode> ::= <BoolTermNode> ( ( Token.OR | Token.AND ) <ExpressionNode> )?
     * @throws ParseException if unexpected token.
     */
    private ASTNode parseExpression() throws ParseException {
        ASTNode left = parseBoolTerm();

        if (lb.peek() == null)
            return left;

        switch (lb.peek().getToken()) {
            case OR:
                lb.consume(Token.OR);
                return new ExpressionNode.Or(left, parseExpression());
            case AND:
                lb.consume(Token.AND);
                return new ExpressionNode.And(left, parseExpression());
        }
        return left;
    }

    private ASTNode parseBoolTerm() throws ParseException {
        ASTNode left = parseBoolFactor();

        if (lb.peek() == null)
            return left;

        switch (lb.peek().getToken()) {
            case LOWER:
                lb.consume(Token.LOWER); // <
                return new BoolTermNode.Lower(left, parseBoolTerm());
            case LEQ:
                lb.consume(Token.LEQ); // <=
                return new BoolTermNode.LEQ(left, parseBoolTerm());
            case GREATER:
                lb.consume(Token.GREATER); // >
                return new BoolTermNode.Greater(left, parseBoolTerm());
            case GEQ:
                lb.consume(Token.GEQ); // >=
                return new BoolTermNode.GEQ(left, parseBoolTerm());
            case EQUAL:
                lb.consume(Token.EQUAL); // ==
                return new BoolTermNode.Equal(left, parseBoolTerm());
            case DIFFERENT:
                lb.consume(Token.DIFFERENT); // <>
                return new BoolTermNode.Different(left, parseBoolTerm());
        }

        return left; // no match
    }

    private ASTNode parseBoolFactor() throws ParseException {
        ASTNode left = parseArithTerm();

        if (lb.peek() == null)
            return left;

        switch (lb.peek().getToken()) {
            case ADDITION:
                lb.consume(Token.ADDITION);
                return new BoolFactorNode.Addition(left, parseBoolFactor());
            case SUBTRACTION:
                lb.consume(Token.SUBTRACTION);
                return new BoolFactorNode.Subtraction(left, parseBoolFactor());
        }
        return left;
    }

    private ASTNode parseArithTerm() throws ParseException {
        ASTNode left = parseFactorTerm();

        if (lb.peek() == null)
            return left;

        switch (lb.peek().getToken()) {
            case MULTIPLICATION:
                lb.consume(Token.MULTIPLICATION);
                return new ArithTermNode.Multiplication(left, parseArithTerm());
            case DIVISION:
                lb.consume(Token.DIVISION);
                return new ArithTermNode.Division(left, parseArithTerm());
            case MODULO:
                lb.consume(Token.MODULO);
                return new ArithTermNode.Modulo(left, parseArithTerm());
        }
        return left;
    }

    private ASTNode parseFactorTerm() throws ParseException {
        switch (lb.peek().getToken()) {
            case ADDITION:
                lb.consume(Token.ADDITION);
                return new ArithFactorNode.Positive(parsePrimary());
            case SUBTRACTION:
                lb.consume(Token.SUBTRACTION);
                return new ArithFactorNode.Negative(parsePrimary());
        }
        return parsePrimary();
    }

    private ASTNode parsePrimary() throws ParseException {
        switch (lb.peek().getToken()) {
            case INT, REAL, STRING, BOOL:
                return parseLiteral();
            case IDENTIFIER:
                return switch (lb.peek2().getToken()) {
                    case OPENPARENTHESIS -> parseFunctionCall();
                    case OPENBRACKETS -> parseArrayAccess();
                    case DOT -> parseRecordAccess();
                    default -> new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
                };
            case OPENPARENTHESIS:
                lb.consume(Token.OPENPARENTHESIS);
                ASTNode exp = parseExpression();
                lb.consume(Token.CLOSEPARENTHESIS);
                return exp; // CHECK maybe the parenthesis are important
        }
        throw new ParseException("Unexpected token while parsing a Primary (" + lb.peek() + ").", 0);
    }

    private LiteralNode parseLiteral() throws ParseException {
        return switch (lb.peek().getToken()) {
            case INT -> new LiteralNode.Int(lb.match(Token.INT).getContent());
            case REAL -> new LiteralNode.Real(lb.match(Token.REAL).getContent());
            case STRING -> new LiteralNode.String(lb.match(Token.STRING).getContent());
            case BOOL -> new LiteralNode.Bool(lb.match(Token.BOOL).getContent());
            default -> throw new ParseException("Unexpected token while parsing literal.", 0);
        };
    }

    private FunctionCallNode parseFunctionCall() throws ParseException {
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        lb.consume(Token.OPENPARENTHESIS);

        ArrayList<ASTNode> args = new ArrayList<>();
        while (lb.peek().getToken() != Token.CLOSEPARENTHESIS) {
            if (args.size() > 0 && lb.peek().getToken() == Token.COMMA)
                lb.consume(Token.COMMA);
            args.add(parseExpression());
        }

        lb.consume(Token.CLOSEPARENTHESIS);
        return new FunctionCallNode(identifier, args);
    }

    private ArrayAccessNode parseArrayAccess() throws ParseException {
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        lb.consume(Token.OPENBRACKETS);
        ASTNode index = parseExpression(); // expression
        lb.consume(Token.CLOSEBRACKETS);
        return new ArrayAccessNode(identifier, index);
    }

    private RecordAccessNode parseRecordAccess() throws ParseException {
        ASTNode record;

        if (lb.peek2().getToken() == Token.DOT)
            record = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        else
            record = parseArrayAccess();

        lb.consume(Token.DOT);
        IdentifierNode fieldIdentifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        return new RecordAccessNode(record, fieldIdentifier);
    }

    private RecordAccessNode parseRecordAccess(ArrayAccessNode record) throws ParseException {
        lb.consume(Token.DOT);
        IdentifierNode fieldIdentifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        return new RecordAccessNode(record, fieldIdentifier);
    }

    private ProcedureNode parseProcedure() throws ParseException {
        lb.consume(Token.PROC);
        IdentifierNode identifier = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        lb.consume(Token.OPENPARENTHESIS);

        ArrayList<ParameterNode> params = new ArrayList<>();
        while (lb.peek().getToken() != Token.CLOSEPARENTHESIS) {
            if (params.size() > 0 && lb.peek().getToken() == Token.COMMA)
                lb.consume(Token.COMMA);
            params.add(parseParameter());
        }

        lb.consume(Token.CLOSEPARENTHESIS);
        return new ProcedureNode(identifier, params, parseReturnType(), parseBlock());
    }

    private ParameterNode parseParameter() throws ParseException {
        return new ParameterNode(new IdentifierNode(lb.match(Token.IDENTIFIER).getContent()), parseType());
    }

    private TypeNode parseReturnType() throws ParseException {
        if (lb.peek().getToken() == Token.VOIDTYPE) {
            lb.consume(Token.VOIDTYPE);
            return new TypeNode.Void();
        }
        return parseType();
    }

    private BlockNode parseBlock() throws ParseException {
        lb.consume(Token.OPENCURLYBRACKETS);

        ArrayList<ASTNode> statements = new ArrayList<>();
        while (lb.peek().getToken() != Token.CLOSECURLYBRACKETS)
            statements.add(parseStatement());

        lb.consume(Token.CLOSECURLYBRACKETS);
        return new BlockNode(statements);
    }

    private ASTNode parseStatement() throws ParseException {
        switch (lb.peek().getToken()) {
            case VAL:
                return parseValue();
            case VAR:
                return parseVariable();
            case IF:
                return parseIf();
            case WHILE:
                return parseWhile();
            case FOR:
                return parseFor();
            case RETURN:
                return parseReturn();
            case DELETE:
                return parseDelete();
        }

        switch (lb.peek2().getToken()) {
            case ASSIGNMENT:
                return parseAssignment();
            case OPENPARENTHESIS:
                FunctionCallNode fc = parseFunctionCall();
                lb.consume(Token.SEMICOLON);
                return fc;
            case DOT:
                return parseRecordAccess();
            case OPENBRACKETS:
                ArrayAccessNode arrayAccess = parseArrayAccess();
                if (lb.peek().getToken() == Token.DOT)
                    return parseRecordAccess(arrayAccess);
                return arrayAccess;
        }
        throw new ParseException("Couldn't parse statement (next: " + lb.peek() + ")." + lb.getProgress(), 0);
    }

    private IfNode parseIf() throws ParseException {
        lb.consume(Token.IF);
        ASTNode condition = parseExpression();
        BlockNode block = parseBlock();

        if (lb.peek().getToken() == Token.ELSE) {
            lb.consume(Token.ELSE);
            return new IfNode.Else(condition, block, parseBlock());
        }

        return new IfNode(condition, block);
    }

    private WhileNode parseWhile() throws ParseException {
        lb.consume(Token.WHILE);
        return new WhileNode(parseExpression(), parseBlock());
    }

    private ForNode parseFor() throws ParseException {
        lb.consume(Token.FOR);
        IdentifierNode i = new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        lb.consume(Token.ASSIGNMENT);
        LiteralNode.Int from = new LiteralNode.Int(lb.match(Token.INT).getContent());
        lb.consume(Token.TO);
        LiteralNode.Int to = new LiteralNode.Int(lb.match(Token.INT).getContent());

        if (lb.peek().getToken() == Token.BY) {
            lb.consume(Token.BY);
            LiteralNode.Int by = new LiteralNode.Int(lb.match(Token.INT).getContent());
            return new ForNode.By(i, from, to, by, parseBlock());
        }

        return new ForNode(i, from, to, parseBlock());
    }

    private AssignmentNode parseAssignment() throws ParseException {
        ASTNode left = switch (lb.peek2().getToken()) {
            case OPENBRACKETS -> parseArrayAccess();
            case DOT -> parseRecordAccess();
            default -> new IdentifierNode(lb.match(Token.IDENTIFIER).getContent());
        };

        lb.consume(Token.ASSIGNMENT);
        ASTNode right = parseExpression();
        lb.consume(Token.SEMICOLON);
        return new AssignmentNode(left, right);
    }

    private ReturnNode parseReturn() throws ParseException {
        lb.consume(Token.RETURN);
        ReturnNode ret = new ReturnNode(parseExpression());
        lb.consume(Token.SEMICOLON);
        return ret;
    }

    private DeleteNode parseDelete() throws ParseException {
        lb.consume(Token.DELETE);
        DeleteNode del = new DeleteNode(new IdentifierNode(lb.match(Token.IDENTIFIER).getContent()));
        lb.consume(Token.SEMICOLON);
        return del;
    }
}
