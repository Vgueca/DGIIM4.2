package compiler.Parser.Visitors;

import compiler.Parser.ASTNode;

public class PrintVisitor {
    public void visit(ASTNode node, int depth) {
        System.out.println("\t".repeat(depth) + node.getClass().getSimpleName());
    }
}
