package compiler.Parser.Visitors;

import compiler.Parser.ASTNode;
import compiler.Parser.Nodes.*;
import compiler.SemanticAnalyzer.SType;
import compiler.SemanticAnalyzer.SemanticAnalyzer;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

public class SemanticVisitor {

    public void visit(ASTNode node, SymbolTable st) {
        // do nothing
    }

    //    public void visit(ArithFactorNode node, SymbolTable st) {}
    //    public void visit(ArithTermNode node, SymbolTable st) {}
    //    public void visit(ArrayAccessNode node, SymbolTable st) {}
    //    public void visit(AssignmentNode node, SymbolTable st) {}
    //    public void visit(BlockNode node, SymbolTable st) {}
    //    public void visit(BoolFactorNode node, SymbolTable st) {}
    //    public void visit(BoolTermNode node, SymbolTable st) {}

    public void visit(CVVNode node, SymbolTable st) throws ParseException {
        // const/val/var declaration so we have to add it to the st
        st.add(node.identifier, node.type);
    }

    public void visit(DeleteNode node, SymbolTable st) throws ParseException {
        st.delete(node.deleted);
    }

    //    public void visit(ExpressionNode node, SymbolTable st) {}
    //    public void visit(FieldDeclarationNode node, SymbolTable st) {}
    //    public void visit(ForNode node, SymbolTable st) {}

    public void visit(FunctionCallNode node, SymbolTable st) throws ParseException, SemanticException {
        SType ftype = st.get(node.identifier);
        if (!(ftype instanceof SType.Function fun))
            throw new SemanticException("Function call not on a function", "You called a non-function.");
        if (node.args.size() != fun.params.size())
            throw new SemanticException("Wrong number of arguments", "Not the right amount of function call arguments.");
        for (int i = 0; i < node.args.size(); i++) {
            if (SemanticAnalyzer.getType(node.args.get(i), st).equals(fun.params.get(i))) {
                System.out.println(SemanticAnalyzer.getType(node.args.get(i), st) + " - " + fun.params.get(i));
                throw new SemanticException("Argument types don't match", "Check your arguments");
            }
        }
    }

    //    public void visit(IdentifierNode node, SymbolTable st) {}
        public void visit(IfNode node, SymbolTable st) throws ParseException, SemanticException {
            if(SemanticAnalyzer.getType(node.condition,st) != new SType.Bool()){
                throw new SemanticException("Condition expected", "There is no condition inside the if statement");
            }
        }
    //    public void visit(LiteralNode node, SymbolTable st) {}
    //    public void visit(ParameterNode node, SymbolTable st) {}
    //    public void visit(PrimaryNode node, SymbolTable st) {}

    public void visit(ProcedureNode node, SymbolTable st) throws ParseException {
        ArrayList<SType> params = new ArrayList<>();
        for (ParameterNode p : node.params)
            params.add(SType.getSType(p.type));
        st.add(node.identifier, new SType.Function(SType.getSType(node.returnType), params));
    }

    //    public void visit(ProgramNode node, SymbolTable st) {}
    //    public void visit(RecordAccessNode node, SymbolTable st) {}

    public void visit(RecordDeclarationNode node, SymbolTable st) throws ParseException {
        HashMap<String, SType> fields = new HashMap<>();
     

    st.add(node.identifier, new SType.Record(fields));
}

    //    public void visit(ReturnNode node, SymbolTable st) {}
    //    public void visit(TypeNode node, SymbolTable st) {}
    //    public void visit(WhileNode node, SymbolTable st) {}

}
