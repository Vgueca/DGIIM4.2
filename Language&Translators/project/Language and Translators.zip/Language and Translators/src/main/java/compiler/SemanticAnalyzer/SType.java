package compiler.SemanticAnalyzer;

import compiler.Parser.Nodes.IdentifierNode;
import compiler.Parser.Nodes.TypeNode;
import compiler.Parser.Visitors.PrintVisitor;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class SType {
    public abstract java.lang.String toString();

    public static class Int extends SType {
        public Int() {
        }

        @Override
        public java.lang.String toString() {
            return "int_t";
        }
    }

    public static class Real extends SType {
        public Real() {
        }

        @Override
        public java.lang.String toString() {
            return "real_t";
        }
    }

    public static class String extends SType {
        public String() {
        }

        @Override
        public java.lang.String toString() {
            return "string_t";
        }
    }

    public static class Bool extends SType {
        public Bool() {
        }

        @Override
        public java.lang.String toString() {
            return "bool_t";
        }
    }

    public static class Void extends SType {
        public Void() {
        }

        @Override
        public java.lang.String toString() {
            return "void_t";
        }
    }

    public static class Id extends SType {
        public Id() {
        }

        @Override
        public java.lang.String toString() {
            return "id_t";
        }
    }

    public static class Array extends SType {
        SType type;

        public Array(SType type) {
            this.type = type;
        }

        @Override
        public java.lang.String toString() {
            return type + "[]";
        }
    }

    public static class Function extends SType {
        public SType returnType;
        public ArrayList<SType> params;

        public Function(SType returnType, ArrayList<SType> params) {
            this.returnType = returnType;
            this.params = params;
        }

        @Override
        public java.lang.String toString() {
            return "(" + params + ") -> " + returnType;
        }
    }

    public static class Record extends SType {
        HashMap<java.lang.String, SType> fields;

        public Record(HashMap<java.lang.String, SType> fields) {
            this.fields = fields;
        }

        @Override
        public java.lang.String toString() {
            return "{" + fields + "}";
        }
    }

    /**
     * Convert a TypeNode.Base to a SType.(Int | Real | String | Bool).
     * @param baseType a base type.
     * @return a new SType matching the baseType.
     */
    public static SType getSType(TypeNode.Base baseType) {
        return switch (baseType.token) {
                    case INTTYPE -> new Int();
                    case REALTYPE -> new Real();
                    case STRINGTYPE -> new String();
                    case BOOLTYPE -> new Bool();
            default -> throw new IllegalStateException("Unexpected value: " + baseType.token);
        };
    }

    public static SType getSType(TypeNode.Array array) {
        return switch (array.baseType.token) {
                    case INTTYPE -> new Array(new Int());
                    case REALTYPE -> new Array(new Real());
                    case STRINGTYPE -> new Array(new String());
                    case BOOLTYPE -> new Array(new Bool());
            default -> throw new IllegalStateException("Unexpected value: " + array.baseType.token);
        };
    }

    public static SType getSType(TypeNode tn) throws ParseException {
        if (tn instanceof TypeNode.Base)
            return getSType((TypeNode.Base) tn);
        else if (tn instanceof TypeNode.Void)
            return new Void();
        else if (tn instanceof TypeNode.Array)
            return getSType((TypeNode.Array) tn);
        else if (tn instanceof TypeNode.Identifier)
            return new Id();
        // TODO identifier?

        tn.accept(new PrintVisitor(), 0);
        throw new ParseException("No matching type.", 0);
    }
}
