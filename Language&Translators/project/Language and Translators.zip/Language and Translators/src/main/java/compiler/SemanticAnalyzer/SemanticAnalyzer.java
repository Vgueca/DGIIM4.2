package compiler.SemanticAnalyzer;

import compiler.Parser.ASTNode;
import compiler.Parser.Nodes.*;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;

import java.text.ParseException;

public class SemanticAnalyzer {

    /**
     * The idea here is to check all the nodes from the return ProgramNode of the Parser getAST() function. We take this node and we use the SType getTypes in order to
     * see if all is semantically right. If not, we throw an error from the possible ones with a description of the error. We have to develop for each type of node a STypegetType"
     * function and then they will be called recursively. Also for implementing SType getType function we will need to define the symboltable, that will be a global variable of our
     * semantic analyzer.
     */

    //    /**
    //     * We analyze the AST obtained from the Paser
    //     * @param node
    //     */
    //    public static void analyze(ProgramNode node, SymbolTable st) throws ParseException {
    //        symboltable = new SymbolTable(null);
    //        node.accept(new PrintVisitor(), 0);
    //    }

    public static SType getType(ASTNode node, SymbolTable st) throws SemanticException, ParseException {
        if (node instanceof ArithFactorNode)
            return getType((ArithFactorNode) node, st);
        else if (node instanceof ArithTermNode)
            return getType((ArithTermNode) node, st);
        else if (node instanceof ArrayAccessNode)
            return getType((ArrayAccessNode) node, st);
        else if (node instanceof BoolFactorNode)
            return getType((BoolFactorNode) node, st);
        else if (node instanceof BoolTermNode)
            return getType((BoolTermNode) node, st);
        else if (node instanceof ExpressionNode)
            return getType((ExpressionNode) node, st);
        else if (node instanceof FunctionCallNode)
            return getType((FunctionCallNode) node, st);
        else if (node instanceof IdentifierNode)
            return getType((IdentifierNode) node, st);
        else if (node instanceof LiteralNode)
            return getType((LiteralNode) node, st);
        else if (node instanceof RecordAccessNode)
            return getType((RecordAccessNode) node, st);
        else if (node instanceof ParameterNode)
            return getType((ParameterNode) node, st);
        throw new SemanticException("Unhandled type", "Tried to get an unhandled type (" + node.getClass() + ").");
    }

    public static SType getType(ArithFactorNode node, SymbolTable st) throws SemanticException, ParseException {
        SType prim = getType(node.prim, st);

        if (node instanceof ArithFactorNode.Positive) {
            if (prim instanceof SType.Int || prim instanceof SType.String || prim instanceof SType.Real) {
                throw new SemanticException("No adequately type", "Only Int, real or string admitted");
            } else {
                return getType(node.prim, st);
            }
        } else if (node instanceof ArithFactorNode.Negative) {
            if (prim instanceof SType.Int || prim instanceof SType.Real) {
                throw new SemanticException("No adequately type", "Only Int or real admitted");
            } else {
                return getType(node.prim, st);
            }
        }
        throw new SemanticException("Unhandled ArithFactor", "You called getType on the wrong type.");
    }

    public static SType getType(ArithTermNode node, SymbolTable st) throws ParseException, SemanticException {
        SType left = getType(node.left, st);
        SType right = getType(node.right, st);

        if (node instanceof ArithTermNode.Modulo) {
            if (left instanceof SType.Int || right instanceof SType.Int) {
                throw new SemanticException("No adequately type", "Only Int  admitted");
            } else {
                return new SType.Int();
            }

        } else if (node instanceof ArithTermNode.Division || node instanceof ArithTermNode.Multiplication) {
            if (left instanceof SType.Int || left instanceof SType.Real || right instanceof SType.Int
                    || right instanceof SType.Real) {
                throw new SemanticException("No adequately type", "Only Int or real admitted");
            } else {
                return getType(node.left, st);
            }
        }
        throw new SemanticException("Not equal types", "The two variables  have different types");
    }

    public static SType getType(ArrayAccessNode node, SymbolTable st) throws ParseException, SemanticException {
        SType atype = st.get(node.identifier);
        if (!(atype instanceof SType.Array))
            throw new SemanticException("Not an array",
                    "Array accesses can only be done on arrays (not: " + atype.getClass().getSimpleName() + ").");
        return ((SType.Array) atype).type;
    }

    //    public static SType getType(AssignmentNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(BlockNode node, SymbolTable st) throws ParseException { return null; }

    public static SType getType(BoolFactorNode node, SymbolTable st) throws ParseException, SemanticException {
        SType left = getType(node.left, st);
        SType right = getType(node.right, st);

        if (node instanceof BoolFactorNode.Subtraction) {
            if (left instanceof SType.Int || left instanceof SType.Real || right instanceof SType.Int
                    || right instanceof SType.Real) {
                throw new SemanticException("No adequately type", "Only Int or real admitted");
            } else {
                return getType(node.left, st);
            }
        } else if (node instanceof BoolFactorNode.Addition) {
            if (left instanceof SType.Int || left instanceof SType.Real || right instanceof SType.Int
                    || right instanceof SType.Real
                    || left instanceof SType.String || right instanceof SType.String) {
                throw new SemanticException("No adequately type", "Only Int, real or string  admitted");
            } else {
                return getType(node.left, st);
            }
        }
        throw new SemanticException("Not equal types", "The two variables  have different types");

    }

    public static SType getType(BoolTermNode node, SymbolTable st) throws ParseException, SemanticException {
        SType left = getType(node.left, st);
        SType right = getType(node.right, st);

        if (node instanceof BoolTermNode.LEQ || node instanceof BoolTermNode.Lower
                || node instanceof BoolTermNode.Greater || node instanceof BoolTermNode.GEQ) {

            if (left instanceof SType.Int || left instanceof SType.Real || right instanceof SType.Int
                    || right instanceof SType.Real) {

                throw new SemanticException("No adequately type", "Only Int or real admitted");
            } else {
                if (getType(node.left, st) == getType(node.right, st)) {
                    return getType(node.left, st);
                } else {
                    throw new SemanticException("Not equal types", "The two variables  have different types");
                }
            }
        } else {
            if (left instanceof SType.Int || left instanceof SType.Real || right instanceof SType.Int
                    || right instanceof SType.Real
                    || left instanceof SType.Bool || right instanceof SType.Bool || left instanceof SType.String
                    || right instanceof SType.String) {
                throw new SemanticException("No adequately type", "Only Int, real, string or boolean admitted");
            } else {
                return new SType.Bool();
            }

        }
    }

    //    public static SType getType(CVVNode.Const node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(CVVNode.Val node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(CVVNode.Var node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(DeleteNode node, SymbolTable st) throws ParseException { return null; }

    public static SType getType(ExpressionNode node, SymbolTable st) throws ParseException, SemanticException {
        if (getType(node.left, st) instanceof SType.Bool || getType(node.right, st) instanceof SType.Bool) {
            throw new SemanticException("Not booleans", "Only booleans are admitted");
        } else {
            return getType(node.left, st);
        }

    }

    //    public static SType getType(FieldDeclarationNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(ForNode node, SymbolTable st) throws ParseException { return null; }

    public static SType getType(FunctionCallNode node, SymbolTable st) throws ParseException, SemanticException {
        SType ftype = st.get(node.identifier);
        if (!(ftype instanceof SType.Function))
            throw new SemanticException("Not a function",
                    "Function calls can only be done on functions (not: " + ftype.getClass().getSimpleName() + ").");
        return ((SType.Function) ftype).returnType;
    }

    public static SType getType(IdentifierNode node, SymbolTable st) throws ParseException {
        return st.get(node);
    }

    //    public static SType getType(IfNode node, SymbolTable st) throws ParseException { return null; }

    public static SType getType(LiteralNode node, SymbolTable st) throws ParseException, SemanticException {
        if (node instanceof LiteralNode.Int)
            return new SType.Int();
        else if (node instanceof LiteralNode.Real)
            return new SType.Real();
        else if (node instanceof LiteralNode.String)
            return new SType.String();
        else if (node instanceof LiteralNode.Bool)
            return new SType.Bool();
        throw new SemanticException("Instance error", "The node isn't an instance of int/real/string/bool.");
    }

    public static SType getType(ParameterNode node, SymbolTable st) throws ParseException {
        return SType.getSType(node.type);
    }

    //    public static SType getType(PrimaryNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(ProcedureNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(ProgramNode node, SymbolTable st) throws ParseException { return null; }

    public static SType getType(RecordAccessNode node, SymbolTable st) throws ParseException, SemanticException {
        SType rtype;
        if (node.record instanceof IdentifierNode rec_id) {
            rtype = st.get(rec_id);
        } else if (node.record instanceof ArrayAccessNode arr_acc) {
            rtype = st.get(arr_acc.identifier);
        } else
            throw new SemanticException("Record can be a var or an access",
                    "You accessed the field of a record but not on a record.");

        if (!(rtype instanceof SType.Record rec))
            throw new SemanticException("Not a record",
                    "Record accesses can only be done on records (not: " + rtype.getClass().getSimpleName() + ").");
        if (!rec.fields.containsKey(node.fieldIdentifier.name))
            throw new SemanticException("Not in the record",
                    "You are trying to access a field that's not in the record.");
        return st.get(node.fieldIdentifier);
    }

    //    public static SType getType(RecordDeclarationNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(ReturnNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(TypeNode node, SymbolTable st) throws ParseException { return null; }
    //    public static SType getType(WhileNode node, SymbolTable st) throws ParseException { return null; }
}
