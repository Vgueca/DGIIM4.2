package compiler.SemanticAnalyzer.SemanticException;

public class SemanticException extends Exception {
    private String name;
    private String description;

    public SemanticException(String name, String description) {
        super();
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "SemanticException{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
