package compiler.SemanticAnalyzer.SemanticException;

public class UndeclaredVariable extends SemanticException {
    public  UndeclaredVariable(String variable1, String type){
        super("Undeclared variable",
                "The variable " +  variable1 + "type (" + type + ") has not been declared previously.");
    }
}
