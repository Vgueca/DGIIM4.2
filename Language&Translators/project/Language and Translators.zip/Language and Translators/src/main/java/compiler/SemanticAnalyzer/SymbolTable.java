package compiler.SemanticAnalyzer;

import compiler.Lexer.Token;
import compiler.Parser.ASTNode;
import compiler.Parser.Nodes.IdentifierNode;
import compiler.Parser.Nodes.ParameterNode;
import compiler.Parser.Nodes.TypeNode;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SymbolTable {
    SymbolTable previousTable;
    HashMap<String, SType> entries;

//    public SymbolTable() throws ParseException {
//        HashMap<String, SType> init = new HashMap<>();
//
//        // default functions
//        init.put("readInt", new SType.Function(new SType.Int(), null));
//        init.put("readReal", new SType.Function(new SType.Real(), null));
//        init.put("readString", new SType.Function(new SType.String(), null));
//
//        ArrayList<SType> writeIntParam = new ArrayList<>();
//        writeIntParam.add(new SType.Int());
//        init.put("writeInt", new SType.Function(new SType.Void(), writeIntParam));
//
//        ArrayList<SType> writeRealParam = new ArrayList<>();
//        writeRealParam.add(new SType.Real());
//        init.put("writeReal", new SType.Function(new SType.Void(), writeRealParam));
//
//        ArrayList<SType> writeParam = new ArrayList<>();
//        writeParam.add(new SType.String());
//        init.put("write", new SType.Function(new SType.Void(), writeParam));
//        init.put("writeln", new SType.Function(new SType.Void(), writeParam));
//
//        previousTable = new SymbolTable(init);
//    }

    public SymbolTable(SymbolTable prev) {
        previousTable = prev;
        entries = new HashMap<>();
    }

//    public SymbolTable(HashMap<String, SType> entriesInit) {
//        previousTable = null;
//        this.entries = entriesInit;
//    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder((previousTable != null ? previousTable + "\n" : "") + "ST {");
        for (Map.Entry<String, SType> s : entries.entrySet())
            ret.append("\n\t").append(s.getKey()).append(" : ").append(s.getValue());
        return ret + "\n}";
    }

    public SymbolTable add(IdentifierNode id, SType type) {
        entries.put(id.name, type);
        return this;
    }

    public SymbolTable add(IdentifierNode id, TypeNode.Base baseType) throws ParseException {
        return add(id, SType.getSType(baseType));
    }

    public SymbolTable add(IdentifierNode id, TypeNode type) throws ParseException {
        if (type instanceof TypeNode.Base) {
            return add(id, ((TypeNode.Base) type));
        } else if (type instanceof TypeNode.Identifier) {
            // TODO get in st
        } else if (type instanceof TypeNode.Array) {
            return add(id, new SType.Array(SType.getSType(((TypeNode.Array) type).baseType)));
        } else if (type instanceof TypeNode.Void) {
            return add(id, new SType.Void());
        }
        throw new ParseException("Unknown type.", 0);
    }

    public SType get(IdentifierNode id) throws ParseException {
        if (entries.containsKey(id.name))
            return entries.get(id.name);
        else if (previousTable == null)
            throw new ParseException("The id (" + id + ") doesn't exist in the SymbolTable.", 0);
        else
            return previousTable.get(id);
    }

    public SymbolTable delete(IdentifierNode id) throws ParseException {
        if (entries.containsKey(id.name)) {
            if (get(id) instanceof SType.Array || get(id) instanceof SType.Record)
                entries.remove(id.name);
            else
                throw new ParseException("You can only delete Arrays and Records.", 0);
        } else if (previousTable == null)
            throw new ParseException("The id (" + id + ") doesn't exist in the SymbolTable.", 0);
        else
            previousTable.delete(id);
        return this;
    }
}
