import compiler.Lexer.Lexer;
import compiler.Lexer.Token;
import compiler.Parser.ASTNode;
import compiler.Parser.Nodes.*;
import compiler.Parser.Parser;
import compiler.Parser.Visitors.SemanticVisitor;
import compiler.SemanticAnalyzer.SemanticException.SemanticException;
import compiler.SemanticAnalyzer.SymbolTable;
import org.junit.Test;

import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.ArrayList;
import compiler.SemanticAnalyzer.SType;

import static org.junit.Assert.assertEquals;

public class TestSemanticAnalyzer {
    @Test
    public void test1() throws  ParseException, SemanticException {
        ArrayList<ASTNode> args = new ArrayList<>();
        args.add(new ParameterNode(new IdentifierNode("variable1"), new TypeNode.Base(Token.INTTYPE)));
        args.add(new ParameterNode(new IdentifierNode("variable2"), new TypeNode.Base(Token.STRINGTYPE)));


        ArrayList<SType> args_types = new ArrayList<>();
        args_types.add(new SType.Int());
        args_types.add(new SType.String());

        FunctionCallNode fc = new FunctionCallNode(new IdentifierNode("main"), args);

        SymbolTable st = new SymbolTable(null);
        st.add(new IdentifierNode("main"), new SType.Function(new SType.Int(),args_types));
        fc.accept(new SemanticVisitor(), st);
    }
    @Test
    public void test2() throws  ParseException, SemanticException {
        // TODO REMOVE this test from the parser
        Parser parser = TestParser.initParser("""
                const PI real = 3.1415;
                var xar string[] = "lol";
                val two int = 17;
                proc main (argc bool, lol int, argv string) void { delete xar; }""");

        ProgramNode ast = parser.getAST();
        //        Parser.printAST(ast);

        SymbolTable st = new SymbolTable(null);
        ast.accept(new SemanticVisitor(), st);
        System.out.println(st);
    }

}
